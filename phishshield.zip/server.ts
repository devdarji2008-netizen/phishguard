import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

// In-memory feedback store with some realistic starter data
const feedbackStore = [
  {
    id: "fb-1",
    name: "Aarav Sharma",
    email: "aarav.sharma@example.com",
    rating: 5,
    message: "Super accurate parsing of suspicious PayPal domains. The heuristic checks flag subdomains instantly.",
    category: "Detection Engine",
    date: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: "fb-2",
    name: "Priya Patel",
    email: "priya.patel@example.com",
    rating: 4,
    message: "The SMS smishing detection caught a text claiming a parcel was held at customs. Helpful tips!",
    category: "Interface & UX",
    date: new Date(Date.now() - 3600000 * 5).toISOString(),
  }
];

// Lazy-initialized GoogleGenAI client helper
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.log("No GEMINI_API_KEY provided or using placeholder. Running in local Heuristic Fallback mode.");
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Local rule-based heuristic scanner (robust backup if Gemini is offline or unconfigured)
function analyzeLocally(type: string, content: string) {
  const text = content.toLowerCase();
  const indicators: string[] = [];
  let riskScore = 10;
  let verdict: "safe" | "suspicious" | "phishing" = "safe";
  let threatType = "Safe / Conversational";
  let detailedExplanation = "Lexical analysis suggests this content is highly consistent with standard patterns.";
  let mitigationRecommendation = "1. Maintain normal security awareness.\n2. Do not input credentials if context changes unexpectedly.";

  if (type === "url") {
    // Check for IP address in host
    if (/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(text)) {
      indicators.push("Uses direct numerical IP address instead of registered domain name.");
      riskScore = Math.max(riskScore, 85);
    }
    // Check for common phishing keyword spoofs
    const brandSpoofKeywords = ["paypal", "netflix", "secure", "verification", "update", "signin", "accounts-", "login-"];
    const foundKeywords = brandSpoofKeywords.filter(k => text.includes(k));
    if (foundKeywords.length > 0) {
      if (text.includes("google.com") || text.includes("paypal.com") || text.includes("netflix.com")) {
        // Safe domain match check
        if (text.includes("accounts.google.com") || text.includes("paypal.com/signin") || text.includes("netflix.com/login")) {
          // Authentic check
        } else {
          indicators.push(`Domain contains mimicking subdomains or suspicious prefixes of recognized keywords: ${foundKeywords.join(", ")}`);
          riskScore = Math.max(riskScore, 75);
        }
      } else {
        indicators.push(`Domain uses high-risk keywords associated with corporate brands or credentials: ${foundKeywords.join(", ")}`);
        riskScore = Math.max(riskScore, 80);
      }
    }
    // Check for shorteners
    if (text.includes("bit.ly") || text.includes("tinyurl.com") || text.includes("t.co")) {
      indicators.push("Uses link redirection/shortening service to conceal absolute destination.");
      riskScore = Math.max(riskScore, 60);
    }
    // Check SSL state (mocked or raw)
    if (content.startsWith("http://")) {
      indicators.push("Uses unencrypted HTTP protocol instead of secure HTTPS connection.");
      riskScore = Math.max(riskScore, 65);
    }
  } else {
    // Email / SMS
    // Urgent phrasing checks
    const urgencyWords = ["urgent", "suspend", "unauthorized", "immediately", "action required", "held", "verify now", "claims", "won", "prize", "billing details"];
    const foundUrgency = urgencyWords.filter(w => text.includes(w));
    if (foundUrgency.length > 0) {
      indicators.push(`Deceptive phrasing leverages high panic/greed keywords: ${foundUrgency.join(", ")}`);
      riskScore = Math.max(riskScore, 70);
    }
    // Call to action links inside message
    if (text.includes("http://") || text.includes("https://") || text.includes(".net/") || text.includes(".org/") || text.includes(".xyz/") || text.includes(".info/")) {
      indicators.push("Message embeds suspicious external redirection link alongside urgency prompt.");
      riskScore = Math.max(riskScore, 75);
    }
    // Poor grammar/odd spacing markers
    if (text.includes("congratulation!") || text.includes("cash cash") || text.includes("parcel-box") || text.includes("detail registry")) {
      indicators.push("Poor grammatical structures and unusual double-words indicative of overseas spam scripts.");
      riskScore = Math.max(riskScore, 55);
    }
  }

  // Compile final results based on risk score
  if (riskScore >= 75) {
    verdict = "phishing";
    threatType = type === "url" ? "Credential Spoofing Domain" : "Social Engineering Bait";
    detailedExplanation = "Heuristic scanner triggered multiple critical safety parameters. The structure leverages deceptive branding patterns and urgent call-to-actions characteristic of live phishing campaigns.";
    mitigationRecommendation = "1. DO NOT open or interact with links in this message.\n2. Report the incident to your IT security division or system administrator.\n3. Verify authentic status by navigating manually to the official brand portal.";
  } else if (riskScore >= 45) {
    verdict = "suspicious";
    threatType = "Suspicious Link/Redirect";
    detailedExplanation = "Moderate anomalies detected. While not definitively malicious, the payload uses generic formatting or shortening flags that warrant heightened vigilance.";
    mitigationRecommendation = "1. Double-check absolute domain name spelling closely before submitting login credentials.\n2. Ensure multi-factor authentication (MFA) is active on your target accounts.";
  }

  if (indicators.length === 0) {
    indicators.push("Zero immediate threat indicators flagged in baseline heuristics scan.");
  }

  return {
    verdict,
    riskScore,
    confidenceScore: 85,
    threatType,
    detectedIndicators: indicators,
    detailedExplanation,
    mitigationRecommendation,
    mode: "Heuristic Guard"
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // GET stats API
  app.get("/api/cyber-intelligence/stats", (req, res) => {
    res.json({
      activeThreatsIndexed: 14209,
      globallyScreened: 1402391 + Math.floor(Math.random() * 1000)
    });
  });

  // GET feedback API
  app.get("/api/feedback", (req, res) => {
    res.json({
      success: true,
      data: feedbackStore
    });
  });

  // POST feedback API
  app.post("/api/feedback", (req, res) => {
    const { name, email, rating, message, category } = req.body;
    const newFb = {
      id: "fb-" + Date.now(),
      name: name || "Anonymous User",
      email: email || "unknown@example.com",
      rating: Number(rating) || 5,
      message: message || "",
      category: category || "General Support",
      date: new Date().toISOString()
    };
    feedbackStore.push(newFb);
    res.json({ success: true, data: newFb });
  });

  // POST phishing analyze API
  app.post("/api/phishing/analyze", async (req, res) => {
    const { type, content } = req.body;
    if (!content) {
      return res.status(400).json({ success: false, error: "Content is required" });
    }

    try {
      const ai = getGeminiClient();
      if (!ai) {
        // Fallback to local analysis
        const analysis = analyzeLocally(type, content);
        return res.json({ success: true, ...analysis });
      }

      // Query Gemini!
      const userPrompt = `
You are an expert Cybersecurity Phishing Attack and Threat Intelligence Analyst.
Analyze the following multi-vector candidate input and produce a detailed phishing safety report:

Candidate Input Vector Type: ${type.toUpperCase()}
Candidate Input Text: "${content}"

Produce a structured JSON report identifying whether this is safe, suspicious, or a verified phishing attack. Use these values:
- verdict: must be strictly one of: 'safe', 'suspicious', 'phishing'
- riskScore: integer from 0 to 100 (where 0 is completely safe and 100 is confirmed severe phishing/scam)
- confidenceScore: integer from 0 to 100 (your confidence in the analysis)
- threatType: concise classification (e.g. "Brand Impersonation", "Urgent Bill Spoofing", "Safe Conversational")
- detectedIndicators: array of specific technical or lexical indicator strings flagged as malicious (e.g. "typosquatting URL", "suspicious subdomains", "false financial urgency", "fake package notice")
- detailedExplanation: a brief professional explanation of the lexical and linguistic features found
- mitigationRecommendation: actionable defensive instructions for the end-user (e.g. "1. Do not enter credentials... 2. Delete the message...")
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: userPrompt,
        config: {
          systemInstruction: "You are a cyber security intelligence analysis server. Analyze input vectors for phishing risk and return precise JSON schema output.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              verdict: {
                type: Type.STRING,
                description: "Must be one of: 'safe', 'suspicious', 'phishing'"
              },
              riskScore: {
                type: Type.INTEGER,
                description: "Integer score from 0 to 100 where higher is riskier."
              },
              confidenceScore: {
                type: Type.INTEGER,
                description: "Your confidence level from 0 to 100."
              },
              threatType: {
                type: Type.STRING,
                description: "Classification category of threat."
              },
              detectedIndicators: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Array of specific indicators of compromise or phishing patterns."
              },
              detailedExplanation: {
                type: Type.STRING,
                description: "Concise analysis of lexical or urgency markers."
              },
              mitigationRecommendation: {
                type: Type.STRING,
                description: "Defensive steps or safety instructions for the user."
              }
            },
            required: ["verdict", "riskScore", "confidenceScore", "threatType", "detectedIndicators", "detailedExplanation", "mitigationRecommendation"]
          }
        }
      });

      const responseText = response.text ? response.text.trim() : "";
      const analysisData = JSON.parse(responseText);

      res.json({
        success: true,
        ...analysisData,
        mode: "Gemini Intel Core"
      });

    } catch (error) {
      console.error("Gemini scan processing exception, applying Heuristic Core Fallback:", error);
      const fallbackAnalysis = analyzeLocally(type, content);
      res.json({ success: true, ...fallbackAnalysis, mode: "Heuristic Core Fallback" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
