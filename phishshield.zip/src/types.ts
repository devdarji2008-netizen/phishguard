export interface PhishingAnalysis {
  verdict: "safe" | "suspicious" | "phishing";
  riskScore: number;
  confidenceScore: number;
  threatType: string;
  detectedIndicators: string[];
  detailedExplanation: string;
  mitigationRecommendation: string;
  mode: string;
}

export interface Feedback {
  id: string;
  name: string;
  email: string;
  rating: number;
  message: string;
  category: string;
  date?: string;
}

export interface SignupProfile {
  email: string;
  name: string;
  password?: string;
}

export interface CyberStats {
  activeThreatsIndexed: number;
  globallyScreened: number;
}
