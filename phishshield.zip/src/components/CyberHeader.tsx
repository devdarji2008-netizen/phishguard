import React from "react";
import { Shield, Lock } from "lucide-react";

interface CyberHeaderProps {
  onLoginClick: () => void;
}

export default function CyberHeader({ onLoginClick }: CyberHeaderProps) {
  return (
    <header className="bg-zinc-950 border-b border-zinc-900 sticky top-0 z-40 backdrop-blur-md bg-opacity-95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-cyan-950/40 border border-cyan-800/30 p-2 rounded-lg text-cyan-400">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-sans text-lg font-bold tracking-tight text-white">
                PhishShield
              </span>
            </div>
            <div className="text-xs text-zinc-500 font-sans">
              Email & URL Security Threat Analyzer
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={onLoginClick}
            type="button"
            className="px-4 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 hover:text-white font-medium font-sans text-xs transition duration-150 flex items-center space-x-2 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-zinc-400" />
            <span>Login</span>
          </button>
        </div>
      </div>
    </header>
  );
}
