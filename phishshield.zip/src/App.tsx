import React, { useState, useEffect } from "react";
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Mail,
  Smartphone,
  Globe2,
  Users,
  MessageSquare,
  Sparkles,
  ArrowRight,
  Terminal,
  Clock,
  Heart,
  Send,
  UserPlus,
  RefreshCw,
  Search,
  CheckCircle,
  Hash,
  X,
  FileCheck,
  Info
} from "lucide-react";
import CyberHeader from "./components/CyberHeader";
import { PhishingAnalysis, Feedback, SignupProfile, CyberStats } from "./types";

export default function App() {
  // Active tab inside interactive detector
  const [activeTab, setActiveTab] = useState<"url" | "email" | "sms">("url");
  const [inputValue, setInputValue] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<PhishingAnalysis | null>(null);

  // Login State Engine
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState<string | null>(null);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState("");

  // Experience Feedback Form (Pre-populated with custom review)
  const [feedbackForm, setFeedbackForm] = useState({
    name: "Darji Dev",
    email: "darji.dev.civil@example.com",
    rating: 5,
    message: "PhishShield detector operates perfectly. Strong heuristic indicators are essential for zero-day defense in both industrial and digital structures.",
    category: "Detection Engine",
  });
  const [feedbackSuccessMsg, setFeedbackSuccessMsg] = useState("");
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  // Cyber statistics loaded from the server
  const [stats, setStats] = useState<CyberStats | null>(null);

  // Dynamic alert simulation banner
  const [simulatedScans, setSimulatedScans] = useState(1402391);

  // Presets for easy user testing
  const presets = {
    url: [
      {
        label: "Secure PayPal Spoof",
        content: "https://paypal-security-verification-update.com/login-access",
        desc: "Phishing Brand Impersonation"
      },
      {
        label: "Unsecured Raw IP Domain",
        content: "http://192.168.12.110/verify-account-credentials",
        desc: "Suspicious Technical Host"
      },
      {
        label: "Official Google URL",
        content: "https://accounts.google.com/signin/v2/challenge",
        desc: "Authentic Google Portal"
      }
    ],
    email: [
      {
        label: "Suspended Account Urgent Bait",
        content: "URGENT NOTICE: Your Netflix access has been suspended due to billing details failure. Click the link within 12 hours to verify your credential profile: http://netflix-billing-recovery.net/login",
        desc: "Urgent Social Engineering"
      },
      {
        label: "Authentic Corporate Circular",
        content: "Dear all, please find attached the weekly summary of current cyber security indicators for the IBM 2-week course. Ensure your local dev servers are secure.",
        desc: "Standard Safe Circular"
      },
      {
        label: "Unexpected Cash Bait",
        content: "Congratulation! Your account hash has won the prize voucher of $5,000. Give detail registry confirmation here to claim cash cash instantly.",
        desc: "Financial Award Fraud"
      }
    ],
    sms: [
      {
        label: "Post Detained Smishing",
        content: "USPS Notice: Your parcel-box has been held at sorting hub because of false zip address. Fix now to prevent package disposal: bit.ly/usps-shipping-customs-fix",
        desc: "Logistics Impersonation"
      },
      {
        label: "OTP Authentication Impersonation",
        content: "ALERT: High risk bank transaction of $1,280 is pending. If you didn't trigger this OTP, immediately tap block-access.com",
        desc: "Credential Smishing"
      },
      {
        label: "Relaxed Social Chat",
        content: "Hey, can you send me the Github link for our cyber security presentation project? Thanks!",
        desc: "Conversational Safe"
      }
    ]
  };

  // Fetch feedback and cyber stats
  const fetchData = async () => {
    try {
      // 1. Fetch Stats
      const statsRes = await fetch("/api/cyber-intelligence/stats");
      const statsData = await statsRes.json();
      if (statsData) setStats(statsData);

      // 2. Fetch Feedback
      setLoadingFeedback(true);
      const feedbackRes = await fetch("/api/feedback");
      const feedbackData = await feedbackRes.json();
      const devFeedback: Feedback = {
        id: "darji-dev-feedback-id",
        name: "Darji Dev (Civil Eng. Sem 5)",
        email: "darji.dev.civil@example.com",
        rating: 5,
        message: "PhishShield is working perfectly. The dynamic heuristic model correctly identifies subdomains and urgency-based phishing text instantly!",
        category: "Detection Engine",
        date: new Date().toISOString()
      };
      if (feedbackData.success) {
        setFeedbackList([devFeedback, ...feedbackData.data]);
      } else {
        setFeedbackList([devFeedback]);
      }
      setLoadingFeedback(false);
    } catch (error) {
      console.error("Error loading server logs:", error);
    }
  };

  useEffect(() => {
    fetchData();

    // Increment simulated scans counter occasionally for active look and feel
    const interval = setInterval(() => {
      setSimulatedScans((prev) => prev + Math.floor(Math.random() * 5) + 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Preset quick fill
  const applyPreset = (content: string) => {
    setInputValue(content);
    setResult(null);
  };

  // Run dynamic analysis
  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    setAnalyzing(true);
    setResult(null);

    try {
      const response = await fetch("/api/phishing/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: activeTab,
          content: inputValue,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setResult({
          verdict: data.verdict,
          riskScore: data.riskScore,
          confidenceScore: data.confidenceScore,
          threatType: data.threatType,
          detectedIndicators: data.detectedIndicators,
          detailedExplanation: data.detailedExplanation,
          mitigationRecommendation: data.mitigationRecommendation,
          mode: data.mode,
        });
      } else {
        alert("Server returned error in verification protocol.");
      }
    } catch (err) {
      console.error("Analysis network failure:", err);
    } finally {
      setAnalyzing(false);
    }
  };

  // Simulated Login and session controllers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginForm.email || !loginForm.password) {
      setLoginError("Please enter academic email and secure access phrase.");
      return;
    }
    setLoginError("");
    setLoginSuccess("");

    // Simulate validation
    if (loginForm.email.includes("@") && loginForm.password.length >= 5) {
      setLoginSuccess("Gateway authorization accepted. Initializing Secure Session...");
      setTimeout(() => {
        setIsLoggedIn(true);
        const userDisplayName = loginForm.email.split("@")[0].replace(/[^a-zA-Z0-9]/g, " ");
        setLoggedInUser(userDisplayName.charAt(0).toUpperCase() + userDisplayName.slice(1));
        setShowLoginModal(false);
        setLoginSuccess("");
        setFeedbackForm((prev) => ({
          ...prev,
          name: userDisplayName,
          email: loginForm.email,
        }));
      }, 1000);
    } else {
      setLoginError("Invalid security credential structure. Passcode must be min. 5 indices.");
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setLoggedInUser(null);
    setLoginForm({ email: "", password: "" });
  };

  // Submit Feedback Review
  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackForm.message) {
      alert("Please offer feedback comments before submission.");
      return;
    }

    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(feedbackForm),
      });

      const data = await response.json();
      if (data.success) {
        setFeedbackSuccessMsg("Feedback registry entry successfully written.");
        setFeedbackForm({
          name: "",
          email: "",
          rating: 5,
          message: "",
          category: "Detection System",
        });
        fetchData();
        // Clear message after 4s
        setTimeout(() => setFeedbackSuccessMsg(""), 4000);
      }
    } catch (err) {
      console.error("Feedback failed:", err);
    }
  };

  // Risk badge generator helper
  function renderVerdictBadge(verdict: "safe" | "suspicious" | "phishing") {
    switch (verdict) {
      case "phishing":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold uppercase tracking-wider">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Phishing Threat</span>
          </span>
        );
      case "suspicious":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold uppercase tracking-wider">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Suspicious Anomalies</span>
          </span>
        );
      case "safe":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-450 font-mono text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Legitimate (Safe)</span>
          </span>
        );
    }
  }

  return (
    <div className="bg-zinc-950 min-h-screen text-zinc-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      <CyberHeader onLoginClick={() => setShowLoginModal(true)} />

      {isLoggedIn && (
        <div className="bg-zinc-900 border-b border-zinc-800 px-4 py-2 sm:px-6 lg:px-8 text-xs flex items-center justify-between font-sans">
          <div className="flex items-center space-x-2 text-emerald-400">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
            <span>Signed in as <strong className="text-white">{loggedInUser}</strong></span>
          </div>
          <button
            onClick={handleLogout}
            type="button"
            className="text-zinc-400 hover:text-white uppercase text-[10px] tracking-wider font-semibold border border-zinc-800 bg-zinc-950 px-2 py-0.5 rounded transition duration-150 cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      )}

      {/* Hero Presentation Subheader */}
      <div className="bg-zinc-950 border-b border-zinc-900 py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs text-zinc-400 mb-2 font-sans">
              <span>Project by <strong className="text-zinc-200">Darji Dev</strong></span>
              <span className="text-zinc-700">•</span>
              <span>Diploma Civil Engineering (Sem 5)</span>
              <span className="text-zinc-700">•</span>
              <span className="text-cyan-400">IBM Cyber Security Internship</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white font-sans">
              AI-Powered Multi-Vector Phishing Attack Detector
            </h2>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl font-sans">
              A robust cybersecurity intelligence portal designed to evaluate URLs, subdomains, email social engineering payloads, and SMS vectors using hybrid heuristics and optional Gemini intelligence.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 shrink-0">
            <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl px-4 py-2.5 min-w-[120px]">
              <div className="text-[10px] font-sans text-zinc-500 uppercase tracking-wider font-semibold">Indexed Threats</div>
              <div className="text-lg font-bold font-mono text-cyan-400 mt-0.5">
                {stats?.activeThreatsIndexed?.toLocaleString() || "14,209"}
              </div>
            </div>
            <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl px-4 py-2.5 min-w-[120px]">
              <div className="text-[10px] font-sans text-zinc-500 uppercase tracking-wider font-semibold">Global Scans</div>
              <div className="text-lg font-bold font-mono text-emerald-450 mt-0.5">
                {simulatedScans.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Detector suite & Education Panel (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-8 font-sans">
          
          {/* SEC 1: Interactive Analysis Suite */}
          <section id="detection-suite" className="bg-zinc-900 border border-zinc-800/80 rounded-xl overflow-hidden shadow-sm">
            {/* Header / Tabs */}
            <div className="border-b border-zinc-800/80 bg-zinc-950/60 p-4 sm:px-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <Shield className="text-cyan-455 w-4 h-4" />
                <h3 className="font-sans text-xs font-bold uppercase tracking-wider text-zinc-300">
                  Scan Sandbox Console
                </h3>
              </div>
              
              <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800">
                <button
                  onClick={() => {
                    setActiveTab("url");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-sans text-xs transition duration-150 cursor-pointer ${
                    activeTab === "url"
                      ? "bg-zinc-800 text-cyan-400 font-semibold border border-zinc-700/50 shadow-sm"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Globe2 className="w-3.5 h-3.5" />
                  <span>URL Scan</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab("email");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-sans text-xs transition duration-150 cursor-pointer ${
                    activeTab === "email"
                      ? "bg-zinc-800 text-cyan-400 font-semibold border border-zinc-700/50 shadow-sm"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email Content</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab("sms");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-sans text-xs transition duration-150 cursor-pointer ${
                    activeTab === "sms"
                      ? "bg-zinc-800 text-cyan-400 font-semibold border border-zinc-700/50 shadow-sm"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>SMS (Smishing)</span>
                </button>
              </div>
            </div>

            {/* Selector-Specific Dynamic Instructions */}
            <div className="p-6 pb-0">
              <div className="bg-zinc-950/60 border border-zinc-800/80 rounded-lg p-4 flex items-start space-x-3">
                <Info className="w-5 h-5 text-cyan-500 shrink-0 mt-0.5" />
                <div className="text-xs text-zinc-400">
                  {activeTab === "url" && (
                    <p>
                      <strong>URL Structural Analysis:</strong> Evaluates domain formatting, raw numerical IPs, potential typosquatting strings (e.g. <code className="bg-zinc-900 text-rose-300 px-1.5 py-0.5 rounded font-mono">paypal-login-secure.xyz</code>), nested credentials, and malicious redirects.
                    </p>
                  )}
                  {activeTab === "email" && (
                    <p>
                      <strong>Email Payload Inspection:</strong> Scans messages for deceptive brand impersonation markers, artificial urgency tactics, high-pressure requests, and credentials harvesting lures.
                    </p>
                  )}
                  {activeTab === "sms" && (
                    <p>
                      <strong>SMS Message & Shortener Review:</strong> Audits messages for shortener redirects (e.g. <code className="bg-zinc-900 text-rose-300 px-1.5 py-0.5 rounded font-mono">bit.ly</code>), fraudulent logistics/delivery alerts, or account suspension alerts.
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Test Templates / Presets Quick Clicks */}
            <div className="p-6 pb-0">
              <div className="text-xs uppercase tracking-wider text-zinc-550 mb-2 font-semibold">
                Select an example to load:
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                {presets[activeTab].map((p, index) => (
                  <button
                    key={index}
                    onClick={() => applyPreset(p.content)}
                    type="button"
                    className="text-left bg-zinc-950 hover:bg-zinc-800/80 border border-zinc-800 rounded-lg p-3 transition duration-150 h-full flex flex-col justify-between group focus:outline-none focus:ring-1 focus:ring-cyan-500 cursor-pointer"
                  >
                    <span className="text-[11px] text-zinc-300 font-sans font-medium group-hover:text-cyan-400 truncate block w-full">
                      {p.label}
                    </span>
                    <span className="text-[10px] text-zinc-500 font-sans mt-1.5 whitespace-nowrap overflow-hidden text-ellipsis block italic">
                      {p.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Core Interactive Scanner Input Area */}
            <div className="p-6">
              <form onSubmit={handleAnalyze} className="space-y-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-2 font-semibold">
                    Enter {activeTab === "url" ? "Suspicious URL / Domain" : `Suspicious ${activeTab} content`}:
                  </label>
                  
                  {activeTab === "url" ? (
                    <div className="relative">
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="e.g. https://secure-verify-paypal.com-login.net/signin"
                        className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 placeholder-zinc-600 rounded-lg px-4 py-3 font-sans text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/30 transition duration-150"
                      />
                      {inputValue && (
                        <button
                          type="button"
                          onClick={() => setInputValue("")}
                          className="absolute right-3.5 top-3 text-zinc-400 hover:text-white cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="relative">
                      <textarea
                        rows={4}
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder={
                          activeTab === "email"
                            ? "Paste the email header or body text here for risk inspection..."
                            : "Type the suspicious SMS message with any URL links here to scan..."
                        }
                        className="w-full bg-zinc-950 border border-zinc-800 text-zinc-100 placeholder-zinc-600 rounded-lg p-4 font-sans text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/30 transition duration-150 resize-none"
                      />
                      {inputValue && (
                        <button
                          type="button"
                          onClick={() => setInputValue("")}
                          className="absolute right-3.5 top-3.5 text-zinc-400 hover:text-white cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="text-[10px] text-zinc-500">
                    *Powered by advanced lexical heuristics and optional Gemini fallback.
                  </div>
                  <button
                    type="submit"
                    disabled={analyzing || !inputValue.trim()}
                    className="relative bg-cyan-500 hover:bg-cyan-400 text-black font-semibold font-sans text-xs px-5 py-2.5 rounded-lg shadow-sm flex items-center space-x-2 transition duration-150 disabled:bg-zinc-800 disabled:text-zinc-500 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {analyzing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Check Risk</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* DYNAMIC SCANNED RESULT DISPLAY CARD */}
              {result && (
                <div className="mt-8 border-t border-zinc-800 pt-6 animate-fadeIn">
                  <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-950/60 relative overflow-hidden">
                    {/* Glowing highlight indicator depending on verdict */}
                    <div
                      className={`absolute top-0 left-0 bottom-0 w-1 ${
                        result.verdict === "phishing"
                          ? "bg-rose-500"
                          : result.verdict === "suspicious"
                          ? "bg-amber-500"
                          : "bg-emerald-500"
                      }`}
                    ></div>

                    {/* Headline verdict bar */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                      <div className="flex items-center space-x-3">
                        {renderVerdictBadge(result.verdict)}
                        <span className="text-xs text-zinc-400">
                          Threat Category:{" "}
                          <strong className="text-zinc-200 font-semibold uppercase">
                            {result.threatType}
                          </strong>
                        </span>
                      </div>
                      <div className="text-xs font-sans bg-zinc-900 border border-zinc-800 px-2.5 py-1 rounded text-zinc-400">
                        Engine: <span className="text-cyan-400 font-medium">{result.mode || "Core Guard"}</span>
                      </div>
                    </div>

                    {/* Metric Gauges Row */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-5 bg-zinc-900/60 rounded-lg p-4 border border-zinc-850">
                      {/* Risk Score Gauge */}
                      <div className="flex items-center space-x-4">
                        <div className="relative flex items-center justify-center">
                          {/* Circle Progress bar track */}
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-zinc-800 fill-none"
                              strokeWidth="5"
                            />
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className={`fill-none transition-all duration-1000 ${
                                result.verdict === "phishing"
                                  ? "stroke-rose-500"
                                  : result.verdict === "suspicious"
                                  ? "stroke-amber-500"
                                  : "stroke-emerald-500"
                              }`}
                              strokeWidth="5"
                              strokeDasharray={String(2 * Math.PI * 26)}
                              strokeDashoffset={
                                String(2 * Math.PI * 26 * (1 - result.riskScore / 100))
                              }
                            />
                          </svg>
                          <span className="absolute font-sans font-bold text-sm text-white">
                            {result.riskScore}%
                          </span>
                        </div>
                        <div>
                          <h4 className="text-xs font-sans uppercase tracking-wider text-zinc-400 font-semibold">
                            Composite Threat Index:
                          </h4>
                          <p className="text-xs text-zinc-500 mt-0.5 font-sans">
                            Cumulative safety score algorithm. Lower is safer.
                          </p>
                        </div>
                      </div>

                      {/* AI Confidence gauge */}
                      <div className="flex items-center space-x-4 border-t md:border-t-0 md:border-l border-zinc-800 pt-3 md:pt-0 md:pl-4">
                        <div className="relative flex items-center justify-center">
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-zinc-800 fill-none"
                              strokeWidth="5"
                            />
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-cyan-500 fill-none transition-all duration-1000"
                              strokeWidth="5"
                              strokeDasharray={String(2 * Math.PI * 26)}
                              strokeDashoffset={
                                String(2 * Math.PI * 26 * (1 - result.confidenceScore / 100))
                              }
                            />
                          </svg>
                          <span className="absolute font-sans font-bold text-sm text-white">
                            {result.confidenceScore}%
                          </span>
                        </div>
                        <div>
                          <h4 className="text-xs font-sans uppercase tracking-wider text-zinc-400 font-semibold">
                            Assessment Confidence:
                          </h4>
                          <p className="text-xs text-zinc-500 mt-0.5 font-sans">
                            Statistical confidence parameter.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Detected Indicators List */}
                    <div className="mb-4">
                      <h4 className="text-xs font-mono uppercase text-zinc-400 mb-2 tracking-wide flex items-center space-x-1.5">
                        <Terminal className="w-3.5 h-3.5 text-rose-450 shrink-0" />
                        <span>Flagged Attack Indicators Verified:</span>
                      </h4>
                      <ul className="space-y-1 bg-zinc-950 p-3.5 rounded border border-zinc-900 font-mono text-[11px] leading-relaxed text-zinc-300">
                        {result.detectedIndicators.map((indicator, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <span className="text-rose-500 text-xs shrink-0 select-none">🚨_</span>
                            <span>{indicator}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Detailed Analysis Explanation */}
                    <div className="mb-4 text-xs text-zinc-300 leading-relaxed font-sans">
                      <h4 className="text-xs font-mono uppercase text-zinc-400 mb-1.5 tracking-wide">
                        Lexical Scan Explanation:
                      </h4>
                      <p className="p-3 bg-zinc-900/40 rounded border border-zinc-850">
                        {result.detailedExplanation}
                      </p>
                    </div>

                    {/* Mitigation Instructions */}
                    <div className="text-xs text-zinc-350 bg-amber-500/5 p-4 rounded-lg border border-amber-500/20">
                      <h4 className="text-xs font-mono uppercase text-amber-400 font-bold mb-2 tracking-wider flex items-center space-x-1.5">
                        <Shield className="w-3.5 h-3.5 text-amber-500" />
                        <span>Defensive Mitigation Playbook:</span>
                      </h4>
                      <div className="whitespace-pre-line leading-relaxed font-mono text-[11px] pl-1 text-amber-300">
                        {result.mitigationRecommendation}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* SEC 2: How PhishShield Works (Interactive Guide) */}
          <section id="how-it-works" className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm relative overflow-hidden">
            <div className="flex items-center space-x-3 mb-6 font-sans">
              <div className="p-2 bg-cyan-950/40 rounded-lg text-cyan-400 border border-cyan-800/30">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-sans tracking-wider text-cyan-400 font-bold bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800">
                  SYSTEM ARCHITECTURE
                </span>
                <h3 className="text-base sm:text-lg font-bold text-white mt-1">
                  How PhishShield Analyzes Threat Vectors
                </h3>
              </div>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed mb-6 font-sans">
              PhishShield runs a comprehensive double-pass heuristic evaluation pipeline on suspected inputs. By combining rigorous validation principles with dynamic syntax analysis, it generates near-instantaneous risk assessments.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans">
              
              {/* Box 1: Lexical Inspection */}
              <div className="bg-zinc-950 border border-zinc-800/80 rounded-xl p-4 transition duration-150 relative">
                <div className="text-[10px] text-cyan-400 mb-2 font-bold flex items-center space-x-1.5 uppercase">
                  <span>01 &bull; Lexical Inspection</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Structure & Subdomains</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                  The system tokenizes the URL or input text. It inspects nested subdomains, verifies HTTP/HTTPS layers, and flags malicious redirect symbols common in credential hijacks.
                </p>
                <div className="mt-3.5 bg-zinc-900/60 p-2 rounded text-[10px] font-mono text-cyan-400 border border-zinc-800">
                  Detects typosquatting e.g., <code className="text-white">wellsfarg0.com</code>
                </div>
              </div>

              {/* Box 2: NLP Urgency Check */}
              <div className="bg-zinc-950 border border-zinc-800/80 rounded-xl p-4 transition duration-150 relative">
                <div className="text-[10px] text-emerald-400 mb-2 font-bold flex items-center space-x-1.5 uppercase font-sans">
                  <span>02 &bull; Behavioral NLP</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Psychological Urgency</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                  Deceptive baits often exploit urgency. PhishShield parses natural language patterns, targeting critical pressure words and generic financial lottery triggers.
                </p>
                <div className="mt-3.5 bg-zinc-900/60 p-2 rounded text-[10px] font-sans text-emerald-450 border border-zinc-800">
                  Filters high-pressure social engineering
                </div>
              </div>

              {/* Box 3: Hybrid AI Intelligence */}
              <div className="bg-zinc-950 border border-zinc-800/80 rounded-xl p-4 transition duration-150 relative">
                <div className="text-[10px] text-indigo-400 mb-2 font-bold flex items-center space-x-1.5 uppercase font-sans">
                  <span>03 &bull; AI Verification</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Gemini AI Audit</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                  When local heuristic thresholds flag critical ambiguity, PhishShield utilizes Gemini models server-side to review context and recommend mitigations.
                </p>
                <div className="mt-3.5 bg-zinc-900/60 p-2 rounded text-[10px] font-sans text-indigo-400 border border-zinc-800">
                  Optional real-time verification
                </div>
              </div>

            </div>

            {/* Workflow steps diagram */}
            <div className="mt-5 p-4 rounded-xl bg-zinc-950 border border-zinc-800/80">
              <h4 className="text-[10px] font-sans uppercase text-zinc-500 tracking-wider mb-3 flex items-center space-x-1.5 font-semibold">
                <span>SYSTEM PROCESSING WORKFLOW PIPELINE:</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-center text-[10px] text-zinc-400 font-sans">
                <div className="bg-zinc-900 p-2.5 rounded border border-zinc-800/50">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 1</span>
                  Input Query submitted
                </div>
                <div className="bg-zinc-900 p-2.5 rounded border border-zinc-800/50">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 2</span>
                  Heuristic rules audit
                </div>
                <div className="bg-zinc-900 p-2.5 rounded border border-zinc-800/50">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 3</span>
                  Score compilation
                </div>
                <div className="bg-zinc-900 p-2.5 rounded border border-zinc-800/50 text-rose-300">
                  <span className="text-rose-400 block font-bold mb-0.5">STEP 4</span>
                  Mitigation Playbook
                </div>
              </div>
            </div>
          </section>

          {/* SEC 3: Student Developer Identity Showcase Card */}
          <section id="student-identity" className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-sm relative overflow-hidden font-sans">
            
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6">
              
              {/* Badge visual left */}
              <div className="flex items-start md:items-center space-x-4">
                <div className="relative shrink-0">
                  <div className="bg-zinc-950 border border-zinc-800 w-16 h-16 rounded-xl flex flex-col items-center justify-center text-cyan-400">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase">Sem 5</span>
                    <Shield className="w-5 h-5 text-cyan-400 my-0.5" />
                    <span className="text-[10px] font-bold text-emerald-400">Civil</span>
                  </div>
                </div>
                
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="bg-cyan-950/40 text-cyan-400 text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-800/30">
                      Primary Developer
                    </span>
                    <span className="bg-emerald-950/30 text-emerald-400 text-[10px] font-medium px-2 py-0.5 rounded border border-emerald-800/20">
                      Submission Authenticated
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white tracking-tight">Darji Dev</h3>
                  <div className="flex flex-col space-y-1 mt-1 text-xs text-zinc-400">
                    <div className="flex items-center space-x-2">
                      <span className="text-zinc-550 text-[10px] uppercase w-16 shrink-0">Branch:</span>
                      <span className="text-zinc-200 font-medium font-sans">Diploma Civil Engineering</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-zinc-550 text-[10px] uppercase w-16 shrink-0 font-sans">Semester:</span>
                      <span className="text-zinc-200 font-sans">5th Semester</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-zinc-500 text-[10px] uppercase w-16 shrink-0 font-sans">Program:</span>
                      <span className="text-zinc-300 font-sans">IBM Skill-Based Cybersecurity Internship</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats badges right */}
              <div className="border-t md:border-t-0 md:border-l border-zinc-800 pt-4 md:pt-0 md:pl-6 flex flex-col justify-center space-y-2 shrink-0">
                <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold font-sans leading-none">
                  Project Status
                </div>
                <div className="grid grid-cols-2 gap-2 font-sans">
                  <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 flex flex-col items-start min-w-[125px]">
                    <span className="text-[9px] text-zinc-500 uppercase font-semibold">Verdict Speed</span>
                    <span className="text-xs font-semibold text-zinc-300 mt-0.5">&lt; 150ms Heuristics</span>
                  </div>
                  <div className="bg-zinc-950 p-2.5 rounded border border-zinc-800 flex flex-col items-start min-w-[125px]">
                    <span className="text-[9px] text-zinc-500 uppercase font-semibold">Defensive Core</span>
                    <span className="text-xs font-semibold text-emerald-400 mt-0.5">3/3 Vectors Active</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Custom details / presentation reflection message */}
            <div className="mt-5 pt-4 border-t border-zinc-800 bg-zinc-950/20 -mx-6 -mb-6 p-6">
              <h4 className="text-[11px] uppercase text-cyan-400 tracking-wider mb-2 flex items-center space-x-1.5 font-bold font-sans">
                <span>Interdisciplinary Project Reflection</span>
              </h4>
              <p className="text-xs text-zinc-450 leading-relaxed font-sans">
                As a student of <strong className="text-zinc-200">Diploma Civil Engineering (Sem 5th)</strong> in the IBM skill-based training program, I chose the cybersecurity track to explore how high-consequence system infrastructures can be defended against phishing breaches. Similar to structural safety in physical civil engineering works, digital asset security depends on resilient validation frameworks, robust entry auditing, and heuristic guardrails that protect vulnerable users from malicious social engineering.
              </p>
            </div>
          </section>

        </div>

        {/* RIGHT COLUMN: Sidebar Form Panels (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col space-y-8">
              {/* COMPONENT 2: Defensive Feedback Registry Submission */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm relative overflow-hidden font-sans">

            <div className="flex items-center space-x-2.5 mb-2.5">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                Experience Feedback Registry
              </h3>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
              IBM Internship Review Portal: Offer feedback regarding scanner performance or log false positive reports.
            </p>

            {feedbackSuccessMsg && (
              <div className="mb-3.5 p-3 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono text-center flex items-center justify-center space-x-1.5">
                <CheckCircle className="w-4 h-4" />
                <span>{feedbackSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleFeedbackSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-zinc-400 mb-1 font-semibold uppercase tracking-wider">User Name:</label>
                  <input
                    type="text"
                    value={feedbackForm.name}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, name: e.target.value })}
                    placeholder="Anonymous"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-white font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-zinc-400 mb-1 font-semibold uppercase tracking-wider">Feedback Sector:</label>
                  <select
                    value={feedbackForm.category}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, category: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-zinc-350 font-sans"
                  >
                    <option value="Detection Engine">Engine Accuracy</option>
                    <option value="Interface & UX">Interface Review</option>
                    <option value="Class curriculum">Internship Utility</option>
                    <option value="False Positive Report">False Positive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-zinc-400 mb-1 font-semibold flex justify-between items-center tracking-wider">
                  <span>DEFENSIVE PERFORMANCE RATING:</span>
                  <span className="text-cyan-400 font-bold bg-zinc-950 px-1.5 rounded">{feedbackForm.rating} / 5</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={feedbackForm.rating}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, rating: Number(e.target.value) })}
                  className="w-full accent-cyan-500 bg-zinc-950 h-1 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[8px] text-zinc-500 pt-0.5">
                  <span>1 - INACCURATE</span>
                  <span>5 - FULLY ACCURATE</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-zinc-400 mb-1 font-semibold uppercase tracking-wider">Feedback Message:</label>
                <textarea
                  required
                  rows={3}
                  value={feedbackForm.message}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, message: e.target.value })}
                  placeholder="Detail your experience with the scanner, false-positives spotted, or thoughts on threat matrices..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-white placeholder-zinc-500 resize-none font-sans"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded font-medium text-xs transition duration-150 cursor-pointer flex items-center justify-center space-x-1"
              >
                <Send className="w-3 h-3 text-cyan-400" />
                <span>SUBMIT FEEDBACK</span>
              </button>
            </form>

            {/* List feedbacks live */}
            <div className="mt-5 pt-4 border-t border-zinc-800">
              <h4 className="text-[10px] uppercase text-zinc-500 tracking-wider mb-2 font-semibold">
                Recent Submission Logs ({feedbackList.length})
              </h4>
              
              {loadingFeedback ? (
                <div className="text-[10px] text-zinc-500 py-1">Loading feedback data...</div>
              ) : feedbackList.length === 0 ? (
                <div className="text-[10px] text-zinc-550 italic text-center p-2">
                  No feedback records registered yet. Submit your feedback above!
                </div>
              ) : (
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {feedbackList.slice(-3).reverse().map((f) => (
                    <div
                      key={f.id}
                      className="text-[10px] p-2 bg-zinc-950 border border-zinc-800 rounded text-zinc-350 leading-normal"
                    >
                      <div className="flex justify-between items-center text-[8px] text-zinc-500 mb-1">
                        <span className="font-bold text-zinc-400 truncate max-w-[96px]">{f.name}</span>
                        <span className="text-cyan-400">★ {f.rating}/5</span>
                      </div>
                      <p className="text-[10px] text-zinc-400 break-words leading-tight">{f.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Secure Internship Submission Badge */}
          <div className="border border-zinc-800 bg-zinc-900 rounded-xl p-4 flex flex-col space-y-1.5 select-none text-[11px] text-zinc-400 font-sans">
            <div className="font-semibold text-white flex items-center space-x-1.5">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>IBM Skills Showcase Track &bull; Civil Eng.</span>
            </div>
            <div className="space-y-0.5">
              <div><span className="text-zinc-500 font-medium">Candidate:</span> Darji Dev (Semester 5)</div>
              <div><span className="text-zinc-500 font-medium">Branch:</span> Diploma Civil Engineering</div>
              <div><span className="text-zinc-500 font-medium">Verified Project:</span> Phishing Threat Detection Sandbox</div>
            </div>
            <div className="text-[10px] text-zinc-500 italic pt-0.5 border-t border-zinc-800">
              This self-contained academic project contains simulated local heuristic analysis filters, an authentic feedback register, and responsive security playbooks.
            </div>
          </div>

        </div>

      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950/70 py-6 mt-12 text-xs text-zinc-500 font-sans">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Security Sandbox Environment</span>
          </div>
          <div>
            IBM Skill-Based Cybersecurity Internship • Diploma Civil Engineering Sem 5 © {new Date().getFullYear()}
          </div>
        </div>
      </footer>

      {/* Dynamic Immersive Login Gateway Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm transition-all duration-200">
          <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl shadow-cyan-500/5 transition-transform duration-200">
            
            {/* Header gradient bar */}
            <div className="bg-gradient-to-r from-cyan-500 to-teal-500 h-1.5 w-full"></div>
            
            {/* Close button */}
            <button
              onClick={() => {
                setShowLoginModal(false);
                setLoginError("");
                setLoginSuccess("");
              }}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white transition duration-150 p-1.5 bg-zinc-950/40 rounded-full border border-zinc-800/40 cursor-pointer"
              type="button"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div className="p-6 sm:p-8">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-cyan-500/10 rounded-xl text-cyan-400 border border-cyan-500/20">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">Academic Identity Access</h3>
                  <p className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest">Cyber Security Portal Gateway</p>
                </div>
              </div>

              {loginError && (
                <div className="mb-4 p-3 rounded bg-rose-500/10 border border-rose-500/30 text-rose-450 text-xs font-mono">
                  {loginError}
                </div>
              )}

              {loginSuccess && (
                <div className="mb-4 p-3 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-450 text-xs font-mono">
                  {loginSuccess}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                    Authorized Academic Email:
                  </label>
                  <input
                    type="email"
                    required
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    placeholder="e.g. darji.dev.civil@example.com"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-cyan-500 text-white rounded-lg px-3 py-2 text-xs focus:outline-none transition duration-150"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                    Secure Access Passcode/phrase:
                  </label>
                  <input
                    type="password"
                    required
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-cyan-500 text-white rounded-lg px-3 py-2 text-xs focus:outline-none transition duration-150"
                  />
                </div>

                <div className="flex items-center justify-end pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-zinc-950 font-bold font-mono text-xs px-5 py-2.5 rounded-lg transition duration-150 shadow-md flex items-center justify-center space-x-1.5 cursor-pointer"
                  >
                    <span>LOGIN</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
